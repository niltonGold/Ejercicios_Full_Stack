class DemoComponent extends React.Component {
  constructor() {
      super();
  }

  render() {
    return (
      <div>
        <h1>Este es mi componente de react como clase</h1>
        <a href="https://www.google.com">Ir a Google</a>
      </div>
    );
  }
}
